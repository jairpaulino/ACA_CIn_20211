import sys
from cx_Freeze import setup, Executable

base = None
if sys.platform == "win32":
    base = "Win32GUI"
if sys.platform == "win64":
    base = "Win64GUI"
    
setup(
    name="Calculadora",
    author="Edson Pacholok (edsonpacholok@gmail.com)",
    version="1.0.0",
    description="Calculadora simples com interface grafica construida com GTK",
    options={'build_exe': {
        'includes': ["gi"],
        'excludes': ['wx', 'email', 'pydoc_data', 'curses'],
        'packages': ["gi"],
        'include_files': includeFiles
    }},
    executables=[
        Executable("manipuladorXML.py",
                   base=base
                   )
    ]
)
